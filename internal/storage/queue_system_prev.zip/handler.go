package queue

import (
    "context"
    "encoding/json"
    "fmt"
)

var handlers = map[string]func(context.Context, json.RawMessage) error{}

func RegisterHandler(name string, fn func(context.Context, json.RawMessage) error) {
    handlers[name] = fn
}

func handleJob(ctx context.Context, job Job) error {
    handler, ok := handlers[job.Type]
    if !ok {
        return fmt.Errorf("no handler for job type")
    }
    return handler(ctx, job.Payload)
}