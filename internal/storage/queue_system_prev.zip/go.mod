module queue_system

go 1.21