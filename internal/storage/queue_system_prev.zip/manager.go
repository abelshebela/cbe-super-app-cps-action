package queue

import (
    "context"
    "fmt"
)

type QueueMode int

const (
    ModeMemory QueueMode = iota
    ModeRedis
    ModeBoth
    ModeFallback
)

type QueueManager struct {
    memory Queue
    redis  Queue
}

func NewQueueManager(memory Queue, redis Queue) *QueueManager {
    return &QueueManager{
        memory: memory,
        redis:  redis,
    }
}

func (qm *QueueManager) Enqueue(ctx context.Context, job Job, mode QueueMode) error {
    switch mode {
    case ModeMemory:
        return qm.memory.Enqueue(ctx, job)

    case ModeRedis:
        return qm.redis.Enqueue(ctx, job)

    case ModeBoth:
        go qm.memory.Enqueue(ctx, job)
        go qm.redis.Enqueue(ctx, job)
        return nil

    case ModeFallback:
        err := qm.redis.Enqueue(ctx, job)
        if err != nil {
            return qm.memory.Enqueue(ctx, job)
        }
        return nil

    default:
        return fmt.Errorf("invalid queue mode")
    }
}