package queue

import (
    "context"
    "sync"
    "time"
)

type RetryJob struct {
    job       Job
    executeAt time.Time
}

type InMemoryQueue struct {
    queue      chan Job
    retryQueue []RetryJob

    mu     sync.Mutex
    cancel context.CancelFunc
}

func NewInMemoryQueue(size int) *InMemoryQueue {
    return &InMemoryQueue{
        queue: make(chan Job, size),
    }
}

func (q *InMemoryQueue) Start(ctx context.Context, workers int) {
    ctx, cancel := context.WithCancel(ctx)
    q.cancel = cancel

    for i := 0; i < workers; i++ {
        go q.worker(ctx)
    }

    go q.retryScheduler(ctx)
}

func (q *InMemoryQueue) Stop() {
    q.cancel()
}

func (q *InMemoryQueue) Enqueue(ctx context.Context, job Job) error {
    select {
    case q.queue <- job:
        return nil
    default:
        return nil
    }
}

func (q *InMemoryQueue) worker(ctx context.Context) {
    for {
        select {
        case <-ctx.Done():
            return
        case job := <-q.queue:
            err := handleJob(ctx, job)
            if err != nil {
                q.scheduleRetry(job)
            }
        }
    }
}

func (q *InMemoryQueue) scheduleRetry(job Job) {
    job.Retry++
    if job.Retry > job.MaxRetry {
        return
    }

    delay := time.Second * time.Duration(1<<job.Retry)

    q.mu.Lock()
    q.retryQueue = append(q.retryQueue, RetryJob{
        job:       job,
        executeAt: time.Now().Add(delay),
    })
    q.mu.Unlock()
}

func (q *InMemoryQueue) retryScheduler(ctx context.Context) {
    ticker := time.NewTicker(200 * time.Millisecond)

    for {
        select {
        case <-ctx.Done():
            return
        case <-ticker.C:
            now := time.Now()

            q.mu.Lock()
            var remaining []RetryJob

            for _, r := range q.retryQueue {
                if r.executeAt.Before(now) {
                    q.queue <- r.job
                } else {
                    remaining = append(remaining, r)
                }
            }

            q.retryQueue = remaining
            q.mu.Unlock()
        }
    }
}