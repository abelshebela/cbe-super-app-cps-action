package queue

import "encoding/json"

type Job struct {
    ID        string          `json:"id"`
    Type      string          `json:"type"`
    Payload   json.RawMessage `json:"payload"`
    Retry     int             `json:"retry"`
    MaxRetry  int             `json:"max_retry"`
    CreatedAt int64           `json:"created_at"`
}