package queue

import (
    "context"
    "encoding/json"
    "time"

    "github.com/redis/go-redis/v9"
)

type RedisQueue struct {
    client *redis.Client

    mainKey       string
    processingKey string
    retryKey      string

    cancel context.CancelFunc
}

func NewRedisQueue(client *redis.Client) *RedisQueue {
    return &RedisQueue{
        client:        client,
        mainKey:       "jobs:main",
        processingKey: "jobs:processing",
        retryKey:      "jobs:retry",
    }
}

func (rq *RedisQueue) Start(ctx context.Context, workers int) {
    ctx, cancel := context.WithCancel(ctx)
    rq.cancel = cancel

    for i := 0; i < workers; i++ {
        go rq.worker(ctx)
    }

    go rq.retryScheduler(ctx)
}

func (rq *RedisQueue) Stop() {
    rq.cancel()
}

func (rq *RedisQueue) Enqueue(ctx context.Context, job Job) error {
    data, _ := json.Marshal(job)
    return rq.client.LPush(ctx, rq.mainKey, data).Err()
}

func (rq *RedisQueue) worker(ctx context.Context) {
    for {
        select {
        case <-ctx.Done():
            return
        default:
        }

        res, err := rq.client.BRPopLPush(ctx, rq.mainKey, rq.processingKey, 0).Result()
        if err != nil {
            continue
        }

        var job Job
        json.Unmarshal([]byte(res), &job)

        err = handleJob(ctx, job)

        if err != nil {
            rq.handleFailure(ctx, job, res)
        } else {
            rq.client.LRem(ctx, rq.processingKey, 1, res)
        }
    }
}

func (rq *RedisQueue) handleFailure(ctx context.Context, job Job, raw string) {
    job.Retry++
    delay := time.Second * time.Duration(1<<job.Retry)

    data, _ := json.Marshal(job)

    rq.client.ZAdd(ctx, rq.retryKey, redis.Z{
        Score:  float64(time.Now().Add(delay).Unix()),
        Member: data,
    })

    rq.client.LRem(ctx, rq.processingKey, 1, raw)
}

func (rq *RedisQueue) retryScheduler(ctx context.Context) {
    ticker := time.NewTicker(time.Second)

    for {
        select {
        case <-ctx.Done():
            return
        case <-ticker.C:
            now := time.Now().Unix()

            jobs, _ := rq.client.ZRangeByScore(ctx, rq.retryKey, &redis.ZRangeBy{
                Min: "-inf",
                Max: fmt.Sprintf("%d", now),
            }).Result()

            for _, j := range jobs {
                rq.client.LPush(ctx, rq.mainKey, j)
                rq.client.ZRem(ctx, rq.retryKey, j)
            }
        }
    }
}